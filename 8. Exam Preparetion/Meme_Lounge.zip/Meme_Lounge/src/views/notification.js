import { html } from "../../node_modules/lit-html/lit-html.js";

const notificationBox = document.getElementById('errorBox');
export function notify(message){
    notificationBox.innerHTML = `<span>${message}</span>`;
    notificationBox.style.display = 'block';

    setTimeout(() =>{
        notificationBox.style.display = 'none';
    },3000)
}


