
https://cdn.vox-cdn.com/thumbor/qYboeJw6sfs5LLCgePJZGjhjP8U=/1400x1400/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/19571008/cxvw3qhv2qgvf71rjedb.jpg

An open-world game by rockstar games, in this game you can do anything that you want, for example, you can steal a car after that kill an innocent human