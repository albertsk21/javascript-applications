import {html} from '../../node_modules/lit-html/lit-html.js';
import { deleteGame, getCommentsFromGame, getGameById, postComment } from '../api/data.js';



const detailsTemplate = (game, isOwner, onDelete, comments, onSubmit, generateForm) =>html`
        <section id="game-details">
            <h1>Game Details</h1>
            <div class="info-section">

                <div class="game-header">
                    <img class="game-img" src="${game.imageUrl}" />
                    <h1>${game.title}</h1>
                    <span class="levels">MaxLevel: ${game.maxLevel}</span>
                    <p class="type">${game.category}</p>
                </div>

                <p class="text">${game.summary}</p>

                
                <!-- Bonus ( for Guests and Users ) -->
                <div class="details-comments">
                    <h2>Comments:</h2>
                        ${comments.length == 0 ?
                             html`<p class="no-comment">No comments.</p>` :  generateComments(comments)}
                    <!-- Display paragraph: If there are no games in the database -->
                    
                </div>

                <!-- Edit/Delete buttons ( Only for creator of this game )  -->
                ${isOwner ? html`<div class="buttons">
                    <a href="/edit/${game._id}" class="button">Edit</a>
                    <a @click = ${onDelete} href="javascript: void(0)" class="button">Delete</a>
                </div>` : ''}
            </div>


            ${!generateForm || isOwner ? '' : html`
            <article class="create-comment">
                <label>Add new comment:</label>
                <form @submit = ${onSubmit} class="form">
                    <textarea name="comment" placeholder="Comment......"></textarea>
                    <input class="btn submit" type="submit" value="Add Comment">
                </form>
            </article>
            `}

        </section>
`

const generateComments = (comments) => html`
        <ul>
            ${comments.map(commentTemplate)}
         </ul>
`

const commentTemplate = (obj) => html`
                <li class="comment">
                    <p>Content: ${obj.comment}</p>
                </li>
`

export async function detailsPage(ctx){
  
    const gameId = ctx.params.id;
    const game = await getGameById(gameId);
    const ownerGameId = game._ownerId;
    const myId = sessionStorage.getItem('userId');
    let isOwner = false;
    const isLogged = sessionStorage.getItem('userId') ? true : false;

    let generateFrom = false;

    if(isLogged || isOwner){
        generateFrom = true;
    }

    if(myId == ownerGameId ){
        isOwner = true;
    }

    
    const comments = await getCommentsFromGame(gameId);
    ctx.render(detailsTemplate(game,isOwner,onDelete,comments,onSubmit,generateFrom));    

    async function onDelete(){
        if(confirm('Are you sure?')){
            await deleteGame(gameId);
            ctx.page.redirect('/');
        }
    }

    async function onSubmit(event){
        event.preventDefault();

        const formData = new FormData(event.target);
        const comment = formData.get('comment');

        let textarea = document.getElementsByTagName('textarea')[0];
        textarea.value = '';
        await postComment({gameId,comment});
        ctx.page.redirect(`/details/${gameId}`);
    }
}