import * as api from '../api/api.js';



export const login = api.login;
export const logout = api.logout;
export const register = api.register;


const host = 'http://localhost:3030';



// Application-specific requests
// get all ads
export async function getAllMemes(){
    return await api.get(host + '/data/memes?sortBy=_createdOn%20desc/data/memes',)
}
// get ad by id
export async function getMemeById(id){
    return await api.get(host  + '/data/memes/' + id);
}
// create ad

export async function createMeme(data){
    return await api.post(host + '/data/memes',data)
}
// edit ad by id
export async function editMeme(id,data){
    return await api.put(host + '/data/memes/' + id,data)
}
// delete ad by id
export async function deleteMeme(id){
    return await api.del(host + '/data/memes/' + id);
}
// get my ads
export async function getMyMemes(userId){
    return await api.get(host + `/data/memes?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`)
}