import { html } from "../../node_modules/lit-html/lit-html.js";
import { setUserNav } from "../app.js";
import { getUserData } from "../utlity.js";
import page from '../../node_modules/page/page.mjs';





export const updateNav = (isLogged) => {


	return isLogged
		? html`
                <div class="user">
                    <a href="/create">Create Meme</a>
                    <div class="profile">
                        <span>Welcome, ${getUserData().email}</span>
                        <a href="/profile">My Profile</a>
                        <a href="javascript:void(0)" @click="${logout}">Logout</a>
                    </div>
                </div>`
		: html`
                <div class="guest">
                    <div class="profile">
                        <a href="/login">Login</a>
                        <a href="/register">Register</a>
                    </div>
                    <a class="active" href="/">Home Page</a>
                </div>`
}
const navBar = (isLogged) => html`
   
        <a href="/all-memes">All Memes</a>
        ${updateNav(isLogged)}
     `

export { navBar }

function logout(){

      
    api.logout();
    setUserNav();
    page.redirect('/');

}