import {html} from '../../node_modules/lit-html/lit-html.js';
import { getAllMemes } from '../api/data.js';
import { setUserNav } from '../app.js';
import { memeTemplate } from './commos/meme.js';



const allMemesTemplate = (memes) => html`
        <section id="meme-feed">
            <h1>All Memes</h1>
            <div id="memes">
                ${memes.length == 0 ? html`<p class="no-memes">No memes in database.</p>`: memes.map(meme => {return memeTemplate(meme)})}
			</div>
        </section>
`;


export async function memesPage(ctx){
    setUserNav();
    const memes = await getAllMemes();
    ctx.render(allMemesTemplate(memes));
}