
/*
create universal module(api.js)
create application specific request(data.js)
setup routing(page.js)
create context decorator middleware(utility functions)
implements views
*/




import {render} from '../node_modules/lit-html/lit-html.js';
import * as api from '../src/api/data.js';
import {getUserData} from '../src/utlity.js'
import page from '../node_modules/page/page.mjs';
import { homePage } from './views/homePage.js';
import { navBar } from './views/navBar.js';
import { memesPage } from './views/allMemes.js';
import { loginPage } from './views/auth.js';


window.api = api;
setUserNav();
let main = document.getElementsByTagName('main')[0];
// document.getElementById("logoutBtn").addEventListener("click",logout)


page('/',decorateContext,homePage);
page('/all-memes',decorateContext,memesPage)
page('/login',decorateContext,loginPage)
page.start();



export function setUserNav(){
    const isLogged = getUserData() ? true : false;


    let nav = document.getElementsByTagName('nav')[0];
    render(navBar(isLogged),nav);

    // let userNav = document.getElementsByClassName('user')[0];
    // let guest =   document.getElementsByClassName('guest')[0];
    // let text = userNav.getElementsByClassName('profile')[0].getElementsByTagName('span')[0];
    // if(user){
    //     userNav.style.display = 'block';
    //     guest.style.display = 'none';
    //     text.textContent = `Welcome, ${user.email}`;
    // }else{
    //     userNav.style.display = 'none';
    //     guest.style.display = 'block';   
    // }

}

function decorateContext(ctx,next){
    ctx.render = (content) => render(content, main);
    ctx.setUserNav = setUserNav;
    ctx.user = getUserData();
    next();
}



function logout(){

      
    api.logout();
    setUserNav();
    page.redirect('/');

}